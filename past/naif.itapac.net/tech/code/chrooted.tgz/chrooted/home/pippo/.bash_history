pwd
ls
ps auxww
bye
exit
